-- المادة الرابعة والثلاثون — إعداد Supabase
-- الصق هذا الملف كاملاً في: Supabase Dashboard ▸ SQL Editor ▸ New query ▸ Run

create table if not exists public.national_messages (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  message    text not null,
  place      text not null,
  lat        double precision,
  lng        double precision,
  created_at timestamptz not null default now(),
  constraint nm_name_len   check (char_length(btrim(name))    between 2 and 40),
  constraint nm_msg_len    check (char_length(btrim(message)) between 5 and 200),
  constraint nm_place_len  check (char_length(btrim(place))   between 1 and 80),
  constraint nm_lat_range  check (lat is null or lat between 15 and 33),
  constraint nm_lng_range  check (lng is null or lng between 33 and 57),
  constraint nm_coord_pair check ((lat is null) = (lng is null))
);

create index if not exists national_messages_created_idx
  on public.national_messages (created_at desc);

-- الأمان على مستوى الصفوف: كل شيء ممنوع إلا ما تسمح به السياسات
alter table public.national_messages enable row level security;

-- صلاحيات الأعمدة: القراءة للجميع، والإدخال في الأعمدة الخمسة فقط (لا يمكن تحديد id أو created_at)
revoke all on public.national_messages from anon, authenticated;
grant select on public.national_messages to anon, authenticated;
grant insert (name, message, place, lat, lng) on public.national_messages to anon, authenticated;
-- لا يوجد أي update أو delete للزوار

drop policy if exists "public read"   on public.national_messages;
drop policy if exists "public insert" on public.national_messages;

create policy "public read" on public.national_messages
  for select to anon, authenticated using (true);

create policy "public insert" on public.national_messages
  for insert to anon, authenticated
  with check (
    char_length(btrim(name))    between 2 and 40
    and char_length(btrim(message)) between 5 and 200
    and char_length(btrim(place))   between 1 and 80
    and (lat is null or lat between 15 and 33)
    and (lng is null or lng between 33 and 57)
    and ((lat is null) = (lng is null))
  );

-- حماية من الإغراق: أقصى 30 مشاركة في الدقيقة لكل الموقع
create or replace function public.national_messages_throttle()
returns trigger language plpgsql as $$
begin
  if (select count(*) from public.national_messages
      where created_at > now() - interval '1 minute') >= 30 then
    raise exception 'too many messages, try again shortly';
  end if;
  return new;
end $$;

drop trigger if exists national_messages_throttle_trg on public.national_messages;
create trigger national_messages_throttle_trg
  before insert on public.national_messages
  for each row execute function public.national_messages_throttle();

-- التحديث اللحظي (Realtime)
do $$ begin
  alter publication supabase_realtime add table public.national_messages;
exception when duplicate_object then null; end $$;
